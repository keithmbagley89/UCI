```
        ****So I have attached a lot of screenshots seeing as many of us have been on slightly different pages as far as how we are getting through this particular project.

        Basically here I created an Elk-Server VM in the Azure Portal.  I added an [elkservers] portion to the ansible hosts file, seeing as this new Elk-Server will be using elkservers instead of webservers like the other two VM's were. Underneath this [elkservers] section I added the Elk-Server Private IP address of 10.0.0.9.

        Under the [webservers] portion I have added 10.0.0.4 and 10.0.0.5 seeing as these are the Private IP's of the other two VM's that we will be communicating with later.

        In the ansible.cfg file I have uncommented the remote_user entry and changed it from root to elkadmin.

        I have also created an ansible-playbook by the name of elk.yml in this same directory. In this playbook the ports are specified and the installs of certain necessary things are also included. Although I did manual installs through the terminal for the majority of these things so far. ( ansible, docker, java, kibana, etc. )

        Additionally, I installed docker-compose and created a small docker-compose.yml in the ansible and the docker directory, in case I needed to run it from either place. I realized it was much easier to just launch the docker-compose file without error as opposed to some of the other options that I had tried.

        I have broken down the rest of the steps below.

```

## Day 1 Activity File: ELK Installation

#### 1. Creating a New VM

Make sure that you are logged into your personal Azure account, where your cloud security unit VMs are located.

- Create a new Ubuntu VM in your virtual network with the following configurations:

    - **RAM**: 4 GB+

    - **IP Address**: The VM must have a public IP address.

    - **Networking**: The VM must be in the same VNet and network security group (NSG) as the machines created in the cloud security week.

    - **Access**: The VM must use the same SSH keys as the Ansible container and your existing jump box. Also, ensure that the NSG only allows access to this new VM from your jump box.

- After creating the new VM in Azure, verify that it works as expected by connecting via SSH from your jump box VM.
    - Open a terminal on your computer and SSH into the jump box.

    - From the jump box, SSH into the new VM you just created.

If the connection succeeds, you are ready to move on to the next step. If not, verify that you used the correct SSH key. If the problem persists, ask a partner or staff member for help.

#### 2. Downloading and Configuring the Container

In this step, you will use Ansible to configure the newly created VM. You will:
- Start your Ansible container and log in.

```
          Start VM in Azure Portal
          ssh elkadmin@52.229.31.39
          
          Now I am elkadmin@Elk-Server

```

- Add the new VM to Ansible's `hosts` file.

```
          Added 10.0.0.9 to hosts file

- Create a playbook that installs Docker and configures the container.

```
          This is my elk.yml and docker-compose.yml
          ( The contents are listed below, and in screenshots )



- Run the playbook to launch the container.

          sudo docker-compose up elk
          or
          sudo docker run -p 5602:5601 -p 9201:9200 -p 5045:5044 -it --name elk sebp/elk
          or
          sudo docker run -p 5601:5601 -p 9200:9200 -p 5044:5044 -it --name elk sebp/elk

          There was a point where I was having an issue due to my elk not shutting down right so it was giving me an 'already one with that same name' error, so I had changed the ports.
          Now, they are both reachable in kibana thru the browser so I have no reason to tamper with them.

          sudo docker stop /elk 
          sudo docker rm /elk
          were necessary here to bring up elk with docker run

You just created a new VM, which you'll use to run your ELK stack. In order to use Ansible to configure this machine, you must add it to the list of machines Ansible can discover and connect to.

- This list is Ansible's **inventory**, and is stored in the `hosts` text file:

  ```
  # /etc/ansible/hosts
  [webservers]
  192.168.0.1
  192.168.0.2

  [othermachines]
  192.168.0.3
  192.168.0.4
  ```

- `[webservers]` and `[othermachines]` are **groups**. When you run playbooks with Ansible, you specify which group to run them on. This allows you to run certain playbooks on some machines, but not on others. 

  **Note:** You do not need to include a group titled `[othermachines]` in your `hosts` file. This is included above as an example.

You should already be in your Ansible VM. Add an `[elkservers]` group to your Ansible VM's `hosts` file by following the steps below on the command line:
  - Edit the inventory file `nano /etc/ansible/hosts`.

  - Add a group called `[elkservers]` and specify the IP address of the VM you just created in Azure.

  **Note:** If you get stuck, consult the starter `hosts` file:
- [Starter Host File](Activities/Stu_Day_One/Unsolved/Resources/hosts.yml)

##### Specifying Targets in Playbooks 

Once you've created the `[elkservers]` group, you'll create a playbook to configure it.

- Today, you'll write a play to configure the ELK server. This play should only run on the VM in the `[elkservers]` group. Recall that you can use the `hosts` option in Ansible to specify which machines to run a set of tasks against.

  ```yaml
  - hosts: elkservers
  - become: True
  - tasks:
    - name: Install Packages
    # Etc...
  ```

- Here, the `hosts` option specifies that these `tasks` should only be run on the machines in the `elkservers` group.

To create this playbook, continue using your terminal to complete the following steps:
- Verify you are in your Ansible container.

- Create a new playbook: `touch /etc/ansible/install-elk.yml`.

- Ensure that the header of the playbook looks like the YAML snippet above. Specifically, it must specify `elkservers` as the target hosts.

Write `tasks` that do the following:
- Runs the following command through the shell: `sysctl -w vm.max_map_count=262144`

```
          sysctl -w vm.max_map_count=262144
          This command I specified earlier, it can be entered manually
          or in the playbooks.

```
  - This command configures the target VM (the machine being configured) to use more memory. This improves performance of the ELK container running inside. 

- Installs the following packages:
  - `docker.io`: The Docker engine, used for running containers.
  - `python-pip`: Package used to install Python software.
  - `docker`: Python client for Docker. Required by ELK.

  ```

          This is shown in screenshots. Added to elk.yml

          ---
        - name: Configure Elk VM with Docker
          hosts: elkservers
          remote_user: elk
          become: true
          tasks:
            # Use apt module
           - name: Install docker.io
             apt:
               force_apt_get: yes
              name: docker.io
              state: present

             # Use apt module
           - name: Install pip
             apt:
               force_apt_get: yes
               name: python-pip
               state: present

              # Use pip module
            - name: Install Docker python module
              pip:
                name: docker
                state: present

              # Use command module
            - name: Increase virtual memory
              command: sysctl -w vm.max_map_count=262144

- Downloads the Docker container called `sebp/elk`.

- Configures the container to start with the following port mappings:
  - `5601:5601`
  - `9200:9200`
  - `5044:5044`
  
  ```

              # Use docker_container module
           - name: download and launch a docker elk container
              docker_container:
               name: elk
                image: sebp/elk
               state: started
                published_ports:
                 - 5601:5601
                 - 9200:9200
                 - 5044:5044
                 - 9300:9300
                 - 5602:5601
                 - 9201:9200
                 - 5045:5044
                 - 9301:9300

        I have added ports 9300 and 9301 due to reading that
        they may be used later on with kibana

```

Hint:** Use the Ansible module `docker-container` along with published port mappings. [More info at Ansible.com](https://docs.ansible.com/ansible/latest/modules/docker_container_module.html#examples).

- Starts the container.

Refer to the documentation on Ansible's [docker_container](https://docs.ansible.com/ansible/latest/modules/docker_container_module.html) and [docker_image](https://docs.ansible.com/ansible/latest/modules/docker_image_module.html) modules for guidance.

#### 3. Launching and Exposing the Container 
Check your playbook for typos and other errors, then run it.

After the playbook completes, you should still be in the Ansible container. From there, use the command line to SSH into the ELK server and ensure that the `sebp/elk` container is running by running: `docker ps`.

- You should see a single row whose second column is `sebp/elk`. Take a screenshot before proceeding to the next step.

**Note**: If you're stuck, refer to the starter `elk-playbook.yaml` file provided: [Starter `elk-playbook` File](Activities/Stu_Day_One/Unsolved/Resources/install-elk.yml).


##### Troubleshooting

If your container fails to start, use the following links to troubleshoot it.

- The most common reason for the container failing to launch is a limit on map counts. Follow [these instructions from Elastic.co](https://www.elastic.co/guide/en/elasticsearch/reference/5.0/vm-max-map-count.html#vm-max-map-count) to verify you meet the requirement.

- Review the [official ELK stack documentation](https://elk-docker.readthedocs.io/#prerequisites).

- If the above steps don't help, you can try manually launching the container with this command: 

  - `sudo docker run -p 5601:5601 -p 9200:9200 -p 5044:5044 -it --name elk sebp/elk`

  ```
          sudo docker run -p 5601:5601 -p 9200:9200 -p 5044:5044 -it --name elk sebp/elk
          
          sudo docker ps -a to check container name

          sudo docker exec -it elk /bin/bash

          After running initially I used the sudo docker start and attach options under the name of my desired VM under the docker ps -a command. This prevented the loss of data configurations typically lost by running the docker run command as it boots as a new VM with that command.

          This puts me as root@73387c7b63ee and successfully starts
          the container, allowing me access to the kibana browser.

          http://52.229.31.39:5601
          ( http://MyElk-ServerIP:5601 )

          Takes me to Elastic Kibana
          http://52.229.31.39:5601/app/kibana#/home


#### 4. Identity and Access Management

The final step is to restrict access to the ELK VM using Azure's network security groups (NSGs). You need to add your public IP address to a whitelist, just as you did when clearing access to your jump box.

- **Note:** Make sure you are on your Azure account for this step.

Recall that the ELK stack's web server runs on port `5601`. Open your virtual network's existing NSG and create an incoming rule for your security group that allows TCP traffic over port `5601` from your public IP address.

- **Note:** If you finish this step in the classroom, you will need to repeat this step at home to connect to Kibana from your personal network.

Verify that you can access your server by navigating to http://[your.VM.IP]:5601. Use the public IP address of your new VM.

- You should see this webpage:

![Kibana](Resources/Kibana_Home.png)

```
        See screenshots

```

If this is what you see, congratulations! Take a screenshot of your dashboard before proceeding.

```

        Create a new Inbound rule in the RedTeam-SG Network security group by the name of elk_web with priority 4092 to ensure it is run first. Source destination is my IP. Which may periodically need to be edited if your ISP changes your IP from time to time. Destination 10.0.0.9. This provides access to elk server from my IP. So now in the browser I can reach kibana via http://MYIPADDRESS:5601.

        Also create new inbound security rules for ports 5601 and 9200 to allow connectivity to the desired data displayed through the kibana browser portal.

```
---

### Day 1 Milestone

In today's class, you:
- Deployed a new VM on your virtual network.
- Created an Ansible play to install and configure an ELK instance.
- Restricted access to the new server.

Completing these steps required you to leverage your systems administration, virtualization, cloud, and automation skills. This is an impressive set of tools to have in your toolkit.

---
© 2020 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.  